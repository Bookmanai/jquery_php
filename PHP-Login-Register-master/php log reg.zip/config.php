<?php
	$host="localhost"; // Host name 
	$username="root"; // Mysql username 
	$password=""; // Mysql password 
	$db_name="login"; // Database name 
	$tbl_name="members"; // Table name
	$salt = "batman is here" // For SHA1 hashing
?>